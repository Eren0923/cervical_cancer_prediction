document.getElementById('predictionForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    // إخفاء الأقسام السابقة
    document.getElementById('resultSection').style.display = 'none';
    document.getElementById('errorSection').style.display = 'none';

    // إظهار مؤشر التحميل
    const resultContent = document.getElementById('resultContent');
    resultContent.innerHTML = '<div class="spinner"></div><p>جاري معالجة البيانات...</p>';
    document.getElementById('resultSection').style.display = 'block';

    // جمع البيانات من النموذج
    const formData = new FormData(this);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }

    try {
        // إرسال البيانات إلى الخادم
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            // عرض النتائج
            displayResults(result);
        } else {
            // عرض رسالة خطأ
            showError(result.error);
        }
    } catch (error) {
        showError('حدث خطأ في الاتصال بالخادم: ' + error.message);
    }
});

function displayResults(result) {
    const resultContent = document.getElementById('resultContent');
    const predictionClass = result.prediction === 1 ? 'prediction-positive' : 'prediction-negative';
    
    let html = `
        <div class="result-item ${predictionClass}">
            <label>النتيجة النهائية:</label>
            <div class="value">${result.result}</div>
        </div>
        
        <div class="result-item">
            <label>احتمالية الإصابة:</label>
            <div class="probability-bar">
                <div class="probability-fill" style="width: ${result.probability_positive * 100}%">
                    ${(result.probability_positive * 100).toFixed(2)}%
                </div>
            </div>
        </div>
        
        <div class="result-item">
            <label>درجة الثقة:</label>
            <div class="value">${result.confidence.toFixed(2)}%</div>
        </div>
        
        <div class="result-item">
            <label>ملاحظة مهمة:</label>
            <p>هذا النظام يقدم تنبؤات بناءً على نموذج تعلم آلي ولا يمكن استخدامه كبديل للتشخيص الطبي الفعلي. يجب استشارة الطبيب المختص للحصول على تشخيص دقيق.</p>
        </div>
    `;
    
    resultContent.innerHTML = html;
    document.getElementById('resultSection').style.display = 'block';
}

function showError(errorMessage) {
    document.getElementById('errorMessage').textContent = errorMessage;
    document.getElementById('errorSection').style.display = 'block';
    document.getElementById('resultSection').style.display = 'none';
}
