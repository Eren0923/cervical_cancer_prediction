from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import os

app = Flask(__name__)

# تحميل النموذج والميزات
model_path = os.path.join('models', 'final_cervical_cancer_model.joblib')
features_path = os.path.join('models', 'model_features.joblib')

model = joblib.load(model_path)
feature_names = joblib.load(features_path)

# تعريف الميزات والأوصاف (باللغة العربية)
feature_descriptions = {
    'Age': 'العمر (سنة)',
    'Number of sexual partners': 'عدد الشركاء الجنسيين',
    'First sexual intercourse': 'سن أول علاقة جنسية (سنة)',
    'Num of pregnancies': 'عدد الحمل',
    'Smokes': 'هل تدخن؟ (0=لا، 1=نعم)',
    'Smokes (years)': 'سنوات التدخين',
    'Smokes (packs/year)': 'عدد علب السجائر في السنة',
    'Hormonal Contraceptives': 'استخدام موانع الحمل الهرمونية (0=لا، 1=نعم)',
    'Hormonal Contraceptives (years)': 'سنوات استخدام موانع الحمل الهرمونية',
    'IUD': 'استخدام اللولب (0=لا، 1=نعم)',
    'IUD (years)': 'سنوات استخدام اللولب',
    'STDs': 'وجود أمراض معدية جنسياً (0=لا، 1=نعم)',
    'STDs (number)': 'عدد الأمراض المعدية الجنسية',
    'STDs:condylomatosis': 'الثآليل التناسلية (0=لا، 1=نعم)',
    'STDs:cervical condylomatosis': 'الثآليل على عنق الرحم (0=لا، 1=نعم)',
    'STDs:vaginal condylomatosis': 'الثآليل المهبلية (0=لا، 1=نعم)',
    'STDs:vulvo-perineal condylomatosis': 'الثآليل الخارجية (0=لا، 1=نعم)',
    'STDs:trichomonas': 'داء المشعرات (0=لا، 1=نعم)',
    'STDs:kyphosis': 'الحداب (0=لا، 1=نعم)',
    'STDs:herpes simplex': 'الهربس البسيط (0=لا، 1=نعم)',
    'STDs:molluscum contagiosum': 'الجدري المائي (0=لا، 1=نعم)',
    'STDs:AIDS': 'الإيدز (0=لا، 1=نعم)',
    'STDs:HIV': 'فيروس نقص المناعة البشرية (0=لا، 1=نعم)',
    'STDs:Hepatitis B': 'التهاب الكبد B (0=لا، 1=نعم)',
    'STDs:HPV': 'فيروس الورم الحليمي البشري (0=لا، 1=نعم)',
    'STDs: Number of diagnosis': 'عدد التشخيصات',
    'STDs: Time since first diagnosis': 'الوقت منذ أول تشخيص (سنة)',
    'STDs: Time since last diagnosis': 'الوقت منذ آخر تشخيص (سنة)',
    'Dx:Cancer': 'تشخيص السرطان (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia': 'الأورام الظهارية داخل عنق الرحم (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;1': 'درجة الأورام الظهارية 1 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;2': 'درجة الأورام الظهارية 2 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;3': 'درجة الأورام الظهارية 3 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;30': 'درجة الأورام الظهارية 30 (0=لا، 1=نعم)',
    'Dx': 'التشخيص العام (0=لا، 1=نعم)',
    'Hinselmann': 'اختبار Hinselmann (0=لا، 1=نعم)',
    'Schiller': 'اختبار Schiller (0=لا، 1=نعم)',
    'Cytology': 'فحص الخلايا (0=لا، 1=نعم)',
    'Biopsy': 'الخزعة (0=لا، 1=نعم)'
}

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return render_template('index.html', features=feature_names, descriptions=feature_descriptions)

@app.route('/predict', methods=['POST'])
def predict():
    """نقطة نهاية التنبؤ"""
    try:
        data = request.get_json()
        
        # استخراج البيانات وتحويلها إلى قائمة بالترتيب الصحيح
        input_data = []
        for feature in feature_names:
            value = data.get(feature, 0)
            input_data.append(float(value))
        
        # تحويل إلى numpy array
        input_array = np.array([input_data])
        
        # التنبؤ
        prediction = model.predict(input_array)[0]
        probability = model.predict_proba(input_array)[0]
        
        # تحويل النتيجة إلى نص واضح
        result = "إيجابي (احتمالية الإصابة بسرطان عنق الرحم)" if prediction == 1 else "سلبي (لا توجد احتمالية ظاهرة للإصابة)"
        
        return jsonify({
            'success': True,
            'prediction': int(prediction),
            'result': result,
            'probability_negative': float(probability[0]),
            'probability_positive': float(probability[1]),
            'confidence': float(max(probability)) * 100
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/about')
def about():
    """صفحة المعلومات"""
    return render_template('about.html')

@app.route('/guide')
def guide():
    """صفحة الدليل"""
    return render_template('guide.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
