import argparse
import joblib
import numpy as np
import os
import pandas as pd

# تحديد مسارات الملفات
MODEL_PATH = os.path.join('models', 'final_cervical_cancer_model.joblib')
FEATURES_PATH = os.path.join('models', 'model_features.joblib')

# تحميل النموذج والميزات
try:
    model = joblib.load(MODEL_PATH)
    feature_names = joblib.load(FEATURES_PATH)
except FileNotFoundError:
    print("خطأ: لم يتم العثور على ملفات النموذج. يرجى التأكد من تشغيل train_model.py أولاً.")
    exit(1)

# تعريف الميزات والأوصاف (باللغة العربية)
feature_descriptions = {
    'Age': 'العمر (سنة)',
    'Number of sexual partners': 'عدد الشركاء الجنسيين',
    'First sexual intercourse': 'سن أول علاقة جنسية (سنة)',
    'Num of pregnancies': 'عدد الحمل',
    'Smokes': 'هل تدخن؟ (0=لا، 1=نعم)',
    'Smokes (years)': 'سنوات التدخين',
    'Smokes (packs/year)': 'عدد علب السجائر في السنة',
    'Hormonal Contraceptives': 'استخدام موانع الحمل الهرمونية (0=لا، 1=نعم)',
    'Hormonal Contraceptives (years)': 'سنوات استخدام موانع الحمل الهرمونية',
    'IUD': 'استخدام اللولب (0=لا، 1=نعم)',
    'IUD (years)': 'سنوات استخدام اللولب',
    'STDs': 'وجود أمراض معدية جنسياً (0=لا، 1=نعم)',
    'STDs (number)': 'عدد الأمراض المعدية الجنسية',
    'STDs:condylomatosis': 'الثآليل التناسلية (0=لا، 1=نعم)',
    'STDs:cervical condylomatosis': 'الثآليل على عنق الرحم (0=لا، 1=نعم)',
    'STDs:vaginal condylomatosis': 'الثآليل المهبلية (0=لا، 1=نعم)',
    'STDs:vulvo-perineal condylomatosis': 'الثآليل الخارجية (0=لا، 1=نعم)',
    'STDs:trichomonas': 'داء المشعرات (0=لا، 1=نعم)',
    'STDs:kyphosis': 'الحداب (0=لا، 1=نعم)',
    'STDs:herpes simplex': 'الهربس البسيط (0=لا، 1=نعم)',
    'STDs:molluscum contagiosum': 'الجدري المائي (0=لا، 1=نعم)',
    'STDs:AIDS': 'الإيدز (0=لا، 1=نعم)',
    'STDs:HIV': 'فيروس نقص المناعة البشرية (0=لا، 1=نعم)',
    'STDs:Hepatitis B': 'التهاب الكبد B (0=لا، 1=نعم)',
    'STDs:HPV': 'فيروس الورم الحليمي البشري (0=لا، 1=نعم)',
    'STDs: Number of diagnosis': 'عدد التشخيصات',
    'STDs: Time since first diagnosis': 'الوقت منذ أول تشخيص (سنة)',
    'STDs: Time since last diagnosis': 'الوقت منذ آخر تشخيص (سنة)',
    'Dx:Cancer': 'تشخيص السرطان (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia': 'الأورام الظهارية داخل عنق الرحم (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;1': 'درجة الأورام الظهارية 1 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;2': 'درجة الأورام الظهارية 2 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;3': 'درجة الأورام الظهارية 3 (0=لا، 1=نعم)',
    'Dx:Cervical intraepithelial neoplasia;30': 'درجة الأورام الظهارية 30 (0=لا، 1=نعم)',
    'Dx': 'التشخيص العام (0=لا، 1=نعم)',
    'Hinselmann': 'اختبار Hinselmann (0=لا، 1=نعم)',
    'Schiller': 'اختبار Schiller (0=لا، 1=نعم)',
    'Cytology': 'فحص الخلايا (0=لا، 1=نعم)',
    'Biopsy': 'الخزعة (0=لا، 1=نعم)'
}

def predict_single_case(args):
    """
    يقوم بالتنبؤ لحالة واحدة باستخدام القيم المدخلة عبر سطر الأوامر.
    """
    input_data = []
    
    # جمع البيانات بالترتيب الصحيح للميزات
    for feature in feature_names:
        # استخدام getattr للحصول على قيمة الوسيطة من الكائن args
        value = getattr(args, feature.replace(' ', '_').replace(':', '').replace(';', ''))
        if value is None:
            # إذا كانت القيمة مفقودة، يمكننا استخدام قيمة افتراضية (مثل المتوسط)
            # لكن لغرض CLI، سنطلب إدخال جميع القيم أو استخدام 0 كافتراضي للميزات الثنائية
            # هنا سنفترض أن المستخدم سيوفر جميع القيم المطلوبة
            print(f"خطأ: القيمة للميزة '{feature_descriptions.get(feature, feature)}' مفقودة.")
            return
        input_data.append(float(value))

    # تحويل إلى numpy array
    input_array = np.array([input_data])
    
    # التنبؤ
    prediction = model.predict(input_array)[0]
    probability = model.predict_proba(input_array)[0]
    
    # عرض النتائج
    print("\n==================================================")
    print("         نتائج التنبؤ بسرطان عنق الرحم")
    print("==================================================")
    
    result_text = "إيجابي (احتمالية الإصابة بسرطان عنق الرحم)" if prediction == 1 else "سلبي (لا توجد احتمالية ظاهرة للإصابة)"
    
    print(f"النتيجة النهائية: {result_text}")
    print(f"احتمالية الإصابة (إيجابي): {probability[1]*100:.2f}%")
    print(f"احتمالية عدم الإصابة (سلبي): {probability[0]*100:.2f}%")
    print(f"درجة الثقة: {max(probability)*100:.2f}%")
    print("\nملاحظة: هذا التنبؤ ليس تشخيصاً طبياً. يرجى استشارة الطبيب.")
    print("==================================================")

def main():
    parser = argparse.ArgumentParser(
        description="نظام التنبؤ بسرطان عنق الرحم باستخدام التعلم الآلي (CLI)",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    # إضافة جميع الميزات كوسائط
    for feature in feature_names:
        # تحويل اسم الميزة إلى صيغة مناسبة لـ argparse
        arg_name = feature.replace(' ', '_').replace(':', '').replace(';', '')
        
        # تحديد نوع الوسيطة (افتراضياً float)
        arg_type = float
        
        # تحديد ما إذا كانت الوسيطة مطلوبة (افتراضياً نعم)
        required = True
        
        # تحديد الوصف
        description = feature_descriptions.get(feature, feature)
        
        parser.add_argument(
            f'--{arg_name}',
            type=arg_type,
            required=required,
            help=f"{description}"
        )

    args = parser.parse_args()
    predict_single_case(args)

if __name__ == '__main__':
    main()
