# نظام التنبؤ بسرطان عنق الرحم (Cervical Cancer Prediction System)

هذا المشروع هو تطبيق متكامل يستخدم التعلم الآلي (Machine Learning) للتنبؤ باحتمالية الإصابة بسرطان عنق الرحم بناءً على عوامل الخطر المختلفة. تم تطوير المشروع بالكامل باستخدام لغة بايثون، ويتضمن واجهة ويب رسومية (GUI) باستخدام إطار عمل Flask، وواجهة سطر أوامر (CLI) للتشغيل من الطرفية.

## 🛠️ التكنولوجيا المستخدمة

*   **لغة البرمجة:** Python 3.11+
*   **إطار عمل الويب:** Flask
*   **التعلم الآلي:** scikit-learn (Random Forest Classifier)
*   **معالجة البيانات:** pandas, numpy
*   **الواجهة الأمامية:** HTML, CSS, JavaScript (مع دعم RTL)

## 🚀 كيفية التشغيل

### 1. المتطلبات الأساسية

تأكد من تثبيت Python 3.11+ على نظامك.

### 2. إعداد البيئة الافتراضية

يوصى بشدة باستخدام بيئة افتراضية لعزل تبعيات المشروع:

```bash
# إنشاء بيئة افتراضية
python3.11 -m venv venv

# تفعيل البيئة الافتراضية
source venv/bin/activate
```

### 3. تثبيت التبعيات

قم بتثبيت جميع المكتبات المطلوبة:

```bash
pip install Flask scikit-learn pandas numpy joblib
```

### 4. تشغيل واجهة الويب (GUI)

لتشغيل التطبيق عبر الويب، استخدم الأمر التالي:

```bash
# تأكد من أنك داخل البيئة الافتراضية
python app.py
```

سيتم تشغيل التطبيق على العنوان `http://127.0.0.1:5000/`. يمكنك الوصول إليه عبر متصفح الويب.

### 5. استخدام واجهة سطر الأوامر (CLI)

يمكنك استخدام واجهة سطر الأوامر لإجراء تنبؤات سريعة مباشرة من الطرفية. يتطلب الأمر إدخال جميع عوامل الخطر كمعاملات.

**مثال على الاستخدام:**

```bash
python cli.py \
    --Age 30 \
    --Number_of_sexual_partners 3 \
    --First_sexual_intercourse 18 \
    --Num_of_pregnancies 2 \
    --Smokes 0 \
    --Smokes_years 0 \
    --Smokes_packs_year 0 \
    --Hormonal_Contraceptives 1 \
    --Hormonal_Contraceptives_years 5 \
    --IUD 0 \
    --IUD_years 0 \
    --STDs 0 \
    --STDs_number 0 \
    --STDscondylomatosis 0 \
    --STDscervical_condylomatosis 0 \
    --STDs_vaginal_condylomatosis 0 \
    --STDs_vulvo_perineal_condylomatosis 0 \
    --STDs_trichomonas 0 \
    --STDs_kyphosis 0 \
    --STDs_herpes_simplex 0 \
    --STDs_molluscum_contagiosum 0 \
    --STDs_AIDS 0 \
    --STDs_HIV 0 \
    --STDs_Hepatitis_B 0 \
    --STDs_HPV 0 \
    --STDs_Number_of_diagnosis 0 \
    --STDs_Time_since_first_diagnosis 0 \
    --STDs_Time_since_last_diagnosis 0 \
    --DxCancer 0 \
    --DxCervical_intraepithelial_neoplasia 0 \
    --DxCervical_intraepithelial_neoplasia1 0 \
    --DxCervical_intraepithelial_neoplasia2 0 \
    --DxCervical_intraepithelial_neoplasia3 0 \
    --DxCervical_intraepithelial_neoplasia30 0 \
    --Dx 0 \
    --Hinselmann 0 \
    --Schiller 0 \
    --Cytology 0 \
    --Biopsy 0
```

**ملاحظة:** يجب استبدال القيم بالأرقام المناسبة للحالة المراد التنبؤ بها.

## 📂 هيكل المشروع

```
cervical_cancer_prediction/
├── app.py                  # تطبيق Flask الرئيسي (واجهة الويب)
├── cli.py                  # واجهة سطر الأوامر (CLI)
├── README.md               # ملف الشرح الحالي
├── models/
│   ├── final_cervical_cancer_model.joblib # النموذج المدرب (Random Forest)
│   └── model_features.joblib              # قائمة بأسماء الميزات بترتيبها الصحيح
├── data/
│   └── cervical_cancer_data.csv           # مجموعة البيانات الأصلية
├── static/
│   ├── css/
│   │   └── style.css       # تنسيقات CSS للواجهة
│   └── js/
│       └── script.js       # سكريبت JavaScript لمعالجة التنبؤ
└── templates/
    ├── index.html          # القالب الرئيسي لإدخال البيانات
    ├── about.html          # صفحة عن البرنامج
    └── guide.html          # صفحة دليل الاستخدام
```

## ⚠️ إخلاء مسؤولية طبية

هذا النظام هو أداة بحثية وتعليمية ولا يجب استخدامه كبديل للتشخيص الطبي المهني. يجب استشارة طبيب مختص للحصول على تشخيص دقيق ومعالجة مناسبة.
